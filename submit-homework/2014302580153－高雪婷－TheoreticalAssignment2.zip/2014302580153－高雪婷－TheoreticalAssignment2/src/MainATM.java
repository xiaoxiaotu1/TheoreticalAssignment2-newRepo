/**
 * Created by gaoxueting on 15/11/5.
 */
        import java.awt.*;
        import javax.swing.*;
        import java.util.ArrayList;
        import java.awt.event.ActionEvent;
        import java.awt.event.ActionListener;



public class MainATM extends JFrame {

    private static final Color ATM_COLOR_1 = new Color(164, 122, 229);
    private static final Color ATM_COLOR_2 = new Color(159, 129, 239);

    public ATM atm;
    private JTextArea textArea;
    private JLabel backgroundImage;
    private ArrayList<JButton> button;
    private String userInput = "";


    public MainATM() {

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setSize(529, 406);
        setLayout(null);

        backgroundImage = new JLabel(new ImageIcon("resource/ATM-bg.png"));
        backgroundImage.setLayout(null);
        backgroundImage.setBounds(0, 0,this.getWidth(),this.getHeight());
        setContentPane(backgroundImage);

        textArea = new JTextArea();
        textArea.setForeground(new Color(87, 47, 149));
        textArea.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBounds(60, 30, 390, 120);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        add(scrollPane);


        buttons = new ArrayList<JButton>();
        ButtonListener buttonListener = new ButtonListener();
        JButton button1 = new JButton("1");
        button1.setBounds(33, 200, 28, 30);
        buttons.add(button1);
        JButton button2 = new JButton("2");
        button2.setBounds(83, 200, 28, 30);
        buttons.add(button2);
        JButton button3 = new JButton("3");
        button3.setBounds(133, 200, 28, 30);
        buttons.add(button3);
        JButton button4 = new JButton("4");
        button4.setBounds(33, 250, 28, 30);
        buttons.add(button4);
        JButton button5 = new JButton("5");
        button5.setBounds(83, 250, 28, 30);
        buttons.add(button5);
        JButton button6 = new JButton("6");
        button6.setBounds(133, 250, 28, 30);
        buttons.add(button6);
        JButton button7 = new JButton("7");
        button7.setBounds(33, 300, 28, 30);
        buttons.add(button7);
        JButton button8 = new JButton("8");
        button8.setBounds(83, 300, 28, 30);
        buttons.add(button8);
        JButton button9 = new JButton("9");
        button9.setBounds(133, 300, 28, 30);
        buttons.add(button9);
        JButton button0 = new JButton("0");
        button0.setBounds(33, 350, 28, 30);
        buttons.add(button0);

        JButton enterButton = new JButton("ENTER");
        enterButton.setBounds(83, 350, 78, 30);
        buttons.add(enterButton);
        add(enterButton);

        for (JButton button: buttons) {
            button.addActionListener(buttonListener);
            add(button);
        }

        atm = new ATM(this);


    }

    public class ButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent event) {
             String buttonText = pressedButton.getText();
            JButton pressedButton = (JButton)event.getSource();
           
            if (!buttonText=="ENTER") {
                textArea.setText(textArea.getText() + buttonText);
                userInput = buttonText+userInput;
            }
            else {
                atm.keypad.userFinishEnter();
            }

        }
    }

    public void updateTextArea(String input) {
        this.textArea.setText(this.textArea.getText() + input);
    }

    public int requireUserInput() {

        int userNumber = Integer.parseInt(this.userInput);
        userInput = "";
        return userNumber;
    }

}
