/**
 * Created by gaoxueting on 15/11/5.
 */

public abstract class Transaction {
    private int accountNumber;
    private Screen screen;
    private BankDatabase bankDatabase;

    public Transaction(int userAccountNumber, Screen atmScreen, BankDatabase atmBankDatabase) {
        this.accountNumber = userAccountNumber;
        this.screen = atmScreen;
        this.bankDatabase = atmBankDatabase;
    }

    public int getAccountNumber() {
        return this.accountNumber;
    }

    public Screen getScreen() {
        return this.screen;
    }

    public BankDatabase getBankDatabase() {
        return this.bankDatabase;
    }

    public abstract void execute();
}
