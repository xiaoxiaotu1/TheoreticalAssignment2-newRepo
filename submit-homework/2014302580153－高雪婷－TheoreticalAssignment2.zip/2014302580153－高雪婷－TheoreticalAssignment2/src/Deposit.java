/**
 * Created by gaoxueting on 15/11/5.
 */

public class Deposit extends Transaction {
    private double amount;
    private Keypad keypad;
    private DepositSlot depositSlot;
    private static final int CANCELED = 0;

    public Deposit(int userAccountNumber, Screen atmScreen, BankDatabase atmBankDatabase, Keypad atmKeypad, DepositSlot atmDepositSlot) {
        super(userAccountNumber, atmScreen, atmBankDatabase);
        this.keypad = atmKeypad;
        this.depositSlot = atmDepositSlot;
    }

    public void execute() {
        BankDatabase bankDatabase = this.getBankDatabase();
        Screen screen = this.getScreen();
        this.amount = this.promptForDepositAmount();
        if(this.amount != 0.0) {
            screen.displayMessage("\nPlease insert a deposit envelope containing ");
            screen.displayDollarAmount(this.amount);
            screen.displayMessageLine(".");
            boolean envelopeReceived = this.depositSlot.isEnvelopeReceived();
            if(envelopeReceived) {
                screen.displayMessageLine("\nYour envelope has been received.\nNOTE: The money just deposited will not be available until we verify the amount of any enclosed cash and your checks clear.");
                bankDatabase.credit(this.getAccountNumber(), this.amount);
            } else {
                screen.displayMessageLine("\nYou did not insert an envelope, so the ATM has canceled your transaction.");
            }
        } else {
            screen.displayMessageLine("\nCanceling transaction...");
        }

    }

    private double promptForDepositAmount() {
        Screen screen = this.getScreen();
        screen.displayMessage("\nPlease enter a deposit amount in CENTS (or 0 to cancel): ");
        int input = this.keypad.getInput();
        return input == 0?0.00:(double)input / 100.00;
    }
}
