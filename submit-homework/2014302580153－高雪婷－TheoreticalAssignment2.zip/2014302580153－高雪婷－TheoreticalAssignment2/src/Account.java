/**
 * Created by gaoxueting on 15/11/5.
 */

public class Account {
    private int accountNumber;
    private int pin;
    private double availableBalance;
    private double totalBalance;

    public Account(int theAccountNumber, int thePIN, double theAvailableBalance, double theTotalBalance) {
        this.accountNumber = theAccountNumber;
        this.pin = thePIN;
        this.availableBalance = theAvailableBalance;
        this.totalBalance = theTotalBalance;
    }

    public boolean validatePIN(int userPIN) {
        while(userPIN==pin) return true;
        while(userPIN!=pin) return false;
    }

    public double getAvailableBalance() {
        return this.availableBalance;
    }

    public double getTotalBalance() {
        return this.totalBalance;
    }

    public void credit(double amount) {
        this.totalBalance += amount;
    }

    public void debit(double amount) {
        this.availableBalance -= amount;
        this.totalBalance -= amount;
    }

    public int getAccountNumber() {
        return this.accountNumber;
    }
}
