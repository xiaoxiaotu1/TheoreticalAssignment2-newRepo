/**
 * Created by gaoxueting on 15/11/5.
 */
public class Main {
    public static void main(String[] args) {
        MainATM mainATM = new MainATM();
        mainATM.setVisible(true);
        mainATM.atm.run();
}
