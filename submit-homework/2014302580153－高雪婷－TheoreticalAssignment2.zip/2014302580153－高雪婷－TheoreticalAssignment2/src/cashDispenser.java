/**
 * Created by gaoxueting on 15/11/5.
 */

public class CashDispenser {
    private static final int INITIAL_COUNT = 500;
    private int count = 500;

    public CashDispenser() {
    }

    public void dispenseCash(int amount) {
        int billsRequired = amount / 20;
        this.count -= billsRequired;
    }

    public boolean isSufficientCashAvailable(int amount) {
        int billsRequired = amount / 20;
        return this.count >= billsRequired;
    }
}
