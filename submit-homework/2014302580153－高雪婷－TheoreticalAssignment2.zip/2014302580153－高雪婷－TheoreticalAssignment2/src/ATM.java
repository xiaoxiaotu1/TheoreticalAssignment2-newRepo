/**
 * Created by gaoxueting on 15/11/5.
 */

public class ATM {
    private boolean userAuthenticated = false;
    private int currentAccountNumber = 0;
    private Screen screen = new Screen();
    private Keypad keypad = new Keypad();
    private CashDispenser cashDispenser = new CashDispenser();
    private DepositSlot depositSlot = new DepositSlot();
    private BankDatabase bankDatabase = new BankDatabase();
    private static final int BALANCE_INQUIRY = 1;
    private static final int WITHDRAWAL = 2;
    private static final int DEPOSIT = 3;
    private static final int EXIT = 4;

    public ATM(MainATM main) {
    }

    public void run() {
        while(true) {
            if(this.userAuthenticated) {
                this.performTransactions();
                this.userAuthenticated = false;
                this.currentAccountNumber = 0;
                this.screen.displayMessageLine("\nThank you! Goodbye!");
            } else {
                this.screen.displayMessageLine("/nWelcome");
                this.authenticateUser();
            }
        }
    }

    private void authenticateUser() {
        this.screen.displayMessage("\nPlease enter your account number: ");
        int accountNumber = this.keypad.getInput();
        this.screen.displayMessage("\nEnter your PIN: ");
        int pin = this.keypad.getInput();
        this.userAuthenticated = this.bankDatabase.authenticateUser(accountNumber, pin);
        if(this.userAuthenticated) {
            this.currentAccountNumber = accountNumber;
        } else {
            this.screen.displayMessageLine("Invalid account number or PIN. Please try again.");
        }

    }

    private void performTransactions() {
        Transaction currentTransaction = null;
        boolean userExited = false;

        while(!userExited) {
            int mainMenuSelection = this.displayMainMenu();
            switch(mainMenuSelection) {
                case 1:
                case 2:
                case 3:
                    currentTransaction = this.createTransaction(mainMenuSelection);
                    currentTransaction.execute();
                    break;
                case 4:
                    this.screen.displayMessageLine("\nExiting the system...");
                    userExited = true;
                    break;
                default:
                    this.screen.displayMessageLine("\nYou did not enter a valid selection. Try again.");
            }
        }

    }

    private int displayMainMenu() {
        this.screen.displayMessageLine("\nMain menu:");
        this.screen.displayMessageLine("1 - View my balance");
        this.screen.displayMessageLine("2 - Withdraw cash");
        this.screen.displayMessageLine("3 - Deposit funds");
        this.screen.displayMessageLine("4 - Exit\n");
        this.screen.displayMessage("Enter a choice: ");
        return this.keypad.getInput();
    }

    private Transaction createTransaction(int type) {
        Object temp = null;
        switch(type) {
            case 1:
                temp = new BalanceInquiry(this.currentAccountNumber, this.screen, this.bankDatabase);
                break;
            case 2:
                temp = new Withdrawal(this.currentAccountNumber, this.screen, this.bankDatabase, this.keypad, this.cashDispenser);
                break;
            case 3:
                temp = new Deposit(this.currentAccountNumber, this.screen, this.bankDatabase, this.keypad, this.depositSlot);
        }

        return (Transaction)temp;
    }
}
