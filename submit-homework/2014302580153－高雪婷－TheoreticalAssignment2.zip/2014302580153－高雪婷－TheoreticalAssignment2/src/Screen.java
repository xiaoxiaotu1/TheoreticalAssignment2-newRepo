/**
 * Created by gaoxueting on 15/11/5.
 */

public class Screen {
    public Screen() {
        private MainATM main;
        public Screen(MainATM main){
            this.main=main;
        };
    }

    public void displayMessage(String message) {
        main.updateTextArea(message);
    }

    public void displayMessageLine(String message) {
        main.updateTextArea("\n"+message);
    }

    public void displayDollarAmount(double amount) {
        String input=String.format("$%,.2f",amount);
        frame.updateTextArea(input);
    }
}
