/**
 * Created by gaoxueting on 15/11/5.
 */

public class ATMCaseStudy {
    public ATMCaseStudy() {
    }

    public static void main(String[] args) {
        ATM theATM = new ATM();
        theATM.run();
    }
}
