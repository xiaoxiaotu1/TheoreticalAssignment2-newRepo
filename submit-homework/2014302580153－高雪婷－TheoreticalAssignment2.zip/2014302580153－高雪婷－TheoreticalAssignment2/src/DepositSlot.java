/**
 * Created by gaoxueting on 15/11/5.
 */
public class DepositSlot {
    public DepositSlot() {
    }

    public boolean isEnvelopeReceived() {
        return true;
    }
}
