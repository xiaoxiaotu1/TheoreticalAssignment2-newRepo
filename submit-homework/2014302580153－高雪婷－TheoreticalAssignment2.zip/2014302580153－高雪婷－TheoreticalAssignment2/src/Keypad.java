import java.util.Scanner;

/**
 * Created by gaoxueting on 15/11/5.
 */
public class Keypad {
    MainATM main;
    boolean marking;

    public Keypad(MainATM main){
        this.main=main;
        marking=false;
    }

    //阻塞线程大法
    public int getUserInput(){

        marking=false;
        if(!marking){
            system.out.print("");
        }
        system.out.println("succeed in blocking thread");
        return main.requireUsrrInput();

    }

    public void userFinishEnter(){
        this.marking=true;
    }
}

