/**
 * Created by gaoxueting on 15/11/5.
 */

public class BankDatabase {
    private Account[] accounts = new Account[2];

    public BankDatabase() {
        this.accounts[0] = new Account(12345,54321, 1000.0, 1200.0);
        this.accounts[1] = new Account(98765, 56789, 200.0, 200.0);
    }

    private Account getAccount(int accountNumber) {
        Account[] var5 = this.accounts;
        int var4 = this.accounts.length;

        for(int var3 = 0; var3 < var4; ++var3) {
            Account currentAccount = var5[var3];
            if(currentAccount.getAccountNumber() == accountNumber) {
                return currentAccount;
            }
        }

        return null;
    }

    public boolean authenticateUser(int userAccountNumber, int userPIN) {
        Account userAccount = this.getAccount(userAccountNumber);
        return userAccount != null?userAccount.validatePIN(userPIN):false;
    }

    public double getAvailableBalance(int userAccountNumber) {
        return this.getAccount(userAccountNumber).getAvailableBalance();
    }

    public double getTotalBalance(int userAccountNumber) {
        return this.getAccount(userAccountNumber).getTotalBalance();
    }

    public void credit(int userAccountNumber, double amount) {
        this.getAccount(userAccountNumber).credit(amount);
    }

    public void debit(int userAccountNumber, double amount) {
        this.getAccount(userAccountNumber).debit(amount);
    }
}
